<?php echo e($slot); ?>

<?php /**PATH /home/leonardo/Documentos/laravel/app_controle_tarefas_v10/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>
<?php echo e($slot); ?>

<?php /**PATH /home/leonardo/Documentos/laravel/app_controle_tarefas_v10/resources/views/vendor/mail/text/subcopy.blade.php ENDPATH**/ ?>
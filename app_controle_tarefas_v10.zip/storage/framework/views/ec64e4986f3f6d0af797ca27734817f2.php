<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e($tarefa->tarefa); ?></div>

                <div class="card-body">
                    <fieldset disabled>
                        <div class="mb-3">
                            <label class="form-label ">Situação</label>
                            <input class="form-control" value="<?php echo e($tarefa->situacao->situacao); ?>">
                        </div>
                        <div class="mb-3">
                            <label class="form-label ">Data Limite de conclusão</label>
                            <input type="date" class="form-control" value="<?php echo e($tarefa->data_limite_conclusao); ?>">
                        </div>
                    </fieldset>    
                    <a href="<?php echo e(url()->previous()); ?>" class="btn btn-primary">Voltar</a> 
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/leonardo/Documentos/laravel/app_controle_tarefas_v10/resources/views/tarefa/show.blade.php ENDPATH**/ ?>
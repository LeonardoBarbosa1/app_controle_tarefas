<?php $__env->startSection('content'); ?>
   <?php if(auth()->guard()->check()): ?>
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-md-8">
                    <div class="card">
                        <div class="card-header">URL não encontrada!</div>

                        <div class="card-body">
                        Desculpe <?php echo e(Auth::user()->name); ?>. A URL acessada não foi encontrada. <br>
                        Clique no botão a seguir para voltar <br>
                        <a class="btn btn-primary" href="<?php echo e(route('tarefa.index')); ?>" >Voltar</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
   <?php endif; ?>
   <?php if(auth()->guard()->guest()): ?>
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-md-8">
                    <div class="card">
                        <div class="card-header">URL não encontrada!</div>

                        <div class="card-body">
                        Desculpe. A URL acessada não foi encontrada. <br>
                        Clique no botão a seguir para voltar <br>
                        <a class="btn btn-primary" href="<?php echo e(route('login')); ?>" >Voltar</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
   <?php endif; ?>
    
    
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/leonardo/Documentos/laravel/app_controle_tarefas_v10/resources/views/erro-url.blade.php ENDPATH**/ ?>
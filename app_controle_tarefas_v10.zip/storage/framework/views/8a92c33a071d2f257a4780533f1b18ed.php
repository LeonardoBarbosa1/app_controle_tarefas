site da aplicação <br>

<?php if(auth()->guard()->check()): ?>
    <h1>Usuário autenticado</h1>
    <?php echo e(Auth::user()->id); ?> <br>
    <?php echo e(Auth::user()->name); ?> <br>
    <?php echo e(Auth::user()->email); ?>

    <?php if(Auth::user()->id == 2): ?>
        <p>Parabens você pode ver a mensagem</p>
    <?php endif; ?>
<?php endif; ?>

<?php if(auth()->guard()->guest()): ?>
<p> Olá visitante </p>
<?php endif; ?><?php /**PATH /home/leonardo/Documentos/laravel/app_controle_tarefas_v10/resources/views/bem-vindo.blade.php ENDPATH**/ ?>
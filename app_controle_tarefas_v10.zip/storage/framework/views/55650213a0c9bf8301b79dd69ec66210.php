[<?php echo e($slot); ?>](<?php echo e($url); ?>)
<?php /**PATH /home/leonardo/Documentos/laravel/app_controle_tarefas_v10/resources/views/vendor/mail/text/header.blade.php ENDPATH**/ ?>
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">
                    <div class="row">
                        <div class="col-6">
                            Tarefas
                        </div>
                        <div class="col-6">
                            <div class="float-sm-end">
                                
                                <a style="margin-right: 5px" href="<?php echo e(route('tarefa.create')); ?>"class=" btn btn-success " >Novo</a>

                                <div id="navbarDropdown" class="btn btn-secondary dropdown-toggle float-sm-end" href="#" role="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre> 
                                    Exportar </div> 
                                <div class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown"> 
                                    <a href="<?php echo e(route('tarefa.exportacao', ['extencao' => 'xlsx'])); ?> " class=" dropdown-item">XLSX</a>
                                    <a href="<?php echo e(route('tarefa.exportacao', ['extencao' => 'csv'])); ?>" class=" dropdown-item">CSV</a>
                                    
                                    <a href="<?php echo e(route('tarefa.exportar')); ?>" target="_blank" class=" dropdown-item">PDF</a>
                                 </div>  

                            </div>
                        </div>
                    </div>
                </div>

                <div class="card-body">
                    <table class="table">
                        <thead>
                          <tr>
                            <th scope="col">ID</th>
                            <th scope="col">Tarefa</th>
                            <th scope="col">Data limite conclusão</th>
                            <th scope="col">Situação</th>
                            <th></th>
                            <th></th>
                            
                          </tr>
                        </thead>
                        <tbody>
                            
                            <?php $__currentLoopData = $tarefas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th scope="row"><?php echo e($t['id']); ?></th>
                                    <td><?php echo e($t['tarefa']); ?></td>
                                    <td><?php echo e(date('d/m/Y', strtotime($t['data_limite_conclusao']))); ?></td>
                                    <td> 
                                        <?php if($t->situacao): ?>
                                            
                                            <?php if($t->situacao->situacao == "CONCLUÍDO"): ?>
                                                <span class="text-success fw-bold"><?php echo e($t->situacao->situacao); ?></span> 
                                            <?php elseif($t->situacao->situacao == "PENDENTE"): ?>
                                                <span class="text-warning fw-bold" ><?php echo e($t->situacao->situacao); ?></span> 
                                            <?php elseif($t->situacao->situacao == "CANCELADO"): ?>
                                                <span class="text-danger fw-bold"><?php echo e($t->situacao->situacao); ?></span>     
                                            <?php endif; ?>
                                        <?php else: ?>
                                        
                                        <span class=" fw-bold">N/A</span>     
                                    
                                        <?php endif; ?></td>
                                    <td> 
                                        <a class="bg-primary px-1 p-1" href="<?php echo e(route('tarefa.edit',$t['id'])); ?>">
                                            <img 
                                                style="width: 20px;
                                                       height: 20px;" 
                                                src="/img/lapis.png" alt="">
                                        </a>
                                    </td>

                                    <td > 
                                        <form  id="form_<?php echo e($t['id']); ?>" method="post" action="<?php echo e(route('tarefa.destroy', ['tarefa' =>$t['id']])); ?>" >
                                            <?php echo method_field('DELETE'); ?>
                                            <?php echo csrf_field(); ?>
                                        </form>
                                        <a class="bg-danger px-1 p-1" href="#" onclick="document.getElementById('form_<?php echo e($t['id']); ?>').submit()"> 
                                            <img 
                                                style="width: 20px;
                                                       height: 20px;" 
                                                src="/img/lixeira.png" alt="">
                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
                         
                        </tbody>
                      </table>
                      
                    
                    <nav>
                        <ul class="pagination">
                        <li class="page-item">
                            <a class="page-link" href="<?php echo e($tarefas->previousPageUrl()); ?>" aria-label="Previous">
                            <span aria-hidden="true">Voltar</span>
                            </a>
                        </li>

                        <?php for($i = 1; $i <= $tarefas->lastPage(); $i++): ?>
                            <li class="page-item <?php echo e($tarefas->currentPage() == $i ? 'active' : ''); ?> ">
                                <a class="page-link" href="<?php echo e($tarefas->url($i)); ?>"><?php echo e($i); ?></a>
                            </li>
                        <?php endfor; ?>
                        

                        <li class="page-item">
                            <a class="page-link" href="<?php echo e($tarefas->nextPageUrl()); ?>" aria-label="Next">
                            <span aria-hidden="true">Avançar</span>
                            </a>
                        </li>
                        </ul>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/leonardo/Documentos/laravel/app_controle_tarefas_v10/resources/views/tarefa/index.blade.php ENDPATH**/ ?>
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Acesso Negado</div>

                <div class="card-body">
                   Desculpe. Você não tem acesso a esse recurso. <br>
                   Clique no botão a seguir para voltar <br>
                   <a class="btn btn-primary" href="<?php echo e(url()->previous()); ?>" >Voltar</a>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/leonardo/Documentos/laravel/app_controle_tarefas_v10/resources/views/acesso-negado.blade.php ENDPATH**/ ?>
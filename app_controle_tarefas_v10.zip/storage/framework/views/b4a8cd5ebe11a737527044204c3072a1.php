<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
            <div class="card-header">Olá <?php echo e(Auth::user()->name); ?> Falta pouco agora! Precisamos apenas que você valide seu e-mail</div>

                <div class="card-body">
                    <?php if(session('resent')): ?>
                        <div class="alert alert-success" role="alert">
                           Reenviamos um e-mail para você com um link de validação
                        </div>
                    <?php endif; ?>

                    Antes de uilizar os recursos da aplicação, por favor valide seu e-mail por meio do link de verificação que encaminhamos para seu e-mail <br>
                    Caso você não tenha recebido o e-mail de validação, clique no link a seguir para receber um novo email <br>
                    <form class="d-inline" method="POST" action="<?php echo e(route('verification.resend')); ?>">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="btn btn-link p-0 m-0 align-baseline">Clique aqui</button>.
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/leonardo/Documentos/laravel/app_controle_tarefas_v10/resources/views/auth/verify.blade.php ENDPATH**/ ?>
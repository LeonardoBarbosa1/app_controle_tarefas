<x-mail::message>
# Introdução

Corpo da mensagem.

- Opção 1
- Opção 2
- Opção 3

<x-mail::button :url="''">
texto do botão
</x-mail::button>

Obrogado!,<br>
{{ config('app.name') }}
</x-mail::message>
